# Training files/train_model.py

# 1. Data Collection & Pre-processing
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib
import pickle
import os

# Load the dataset
try:
    # Go up one level to the main project folder, then into Dataset
    df = pd.read_csv('../Dataset/garments_worker_productivity.csv')
    print("Dataset loaded successfully.")
except FileNotFoundError:
    print("Error: Dataset file 'garments_worker_productivity.csv' not found. Please ensure it's in the Dataset/ folder.")
    exit()

# 2. Data Pre-processing
# The target variable is defined as whether the actual productivity is higher than the targeted productivity.
df['performance_label'] = (df['actual_productivity'] > df['targeted_productivity']).astype(int)

# Drop redundant or non-predictive columns. 'wip' is dropped due to a large number of missing values.
df = df.drop(columns=['date', 'actual_productivity', 'idle_time', 'idle_men', 'wip'])
df.dropna(inplace=True)

# Define features and target
X = df.drop('performance_label', axis=1)
y = df['performance_label']

# Define categorical and numerical features
categorical_features = ['quarter', 'department', 'day']
numerical_features = X.drop(columns=categorical_features).columns

# Create a preprocessing pipeline to handle scaling and one-hot encoding
preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numerical_features),
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
    ],
    remainder='passthrough'
)

# 3. Model Building
# Create a full pipeline that combines the preprocessor and a Random Forest Classifier
model_pipeline = Pipeline(steps=[('preprocessor', preprocessor),
                                 ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))])

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# Train the model
model_pipeline.fit(X_train, y_train)

# Evaluating performance of model
y_pred = model_pipeline.predict(X_test)
print("\nModel Evaluation:")
print(f"Accuracy: {accuracy_score(y_test, y_pred):.4f}")
print("Classification Report:")
print(classification_report(y_test, y_pred))
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# Save the model
joblib.dump(model_pipeline, 'gwp.pkl')
print("\nModel 'gwp.pkl' saved successfully in Training files.")

# Create and save a pickle version (as requested)
with open('mcle.pkl', 'wb') as file:
    pickle.dump(model_pipeline, file)
print("Model 'mcle.pkl' saved successfully in Training files.")

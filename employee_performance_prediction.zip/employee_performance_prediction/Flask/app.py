from flask import Flask, render_template, request
import pandas as pd
import joblib
import os
app = Flask(__name__, template_folder='templates')

# Define the path to the model file
model_path = os.path.join(os.path.dirname(__file__), 'gwp.pkl')
try:
    # Load the trained model
    model = joblib.load(model_path)
    print("Model loaded successfully.")
except FileNotFoundError:
    print(f"Error: Model file 'gwp.pkl' not found at {model_path}. Please train the model first.")
    model = None

@app.route('/')
def home():
    """Renders the home page of the application."""
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    """Handles the prediction logic for the web application."""
    if request.method == 'POST' and model:
        try:
            # Get data from form
            data = {
                'quarter': request.form['quarter'],
                'department': request.form['department'],
                'day': request.form['day'],
                'team': int(request.form['team']),
                'targeted_productivity': float(request.form['targeted_productivity']),
                'smv': float(request.form['smv']),
                'over_time': int(request.form['over_time']),
                'incentive': float(request.form['incentive']),
                'no_of_style_change': int(request.form['no_of_style_change']),
                'no_of_workers': float(request.form['no_of_workers'])
            }
            
            # Convert to DataFrame
            input_df = pd.DataFrame([data])
            
            # Make a prediction using the full pipeline
            prediction = model.predict(input_df)[0]
            
            performance_status = "High Performer" if prediction == 1 else "Low Performer"
            
            return render_template('index.html', prediction_text=f'Predicted Performance: {performance_status}')
        
        except Exception as e:
            return render_template('index.html', prediction_text=f"An error occurred: {e}")
    
    return render_template('index.html', prediction_text="Model not loaded. Please check the server logs.")

if __name__ == '__main__':
    app.run(debug=True)
